/**
 * Created by BiuBiu_Jiao on 2016/11/2.
 */
define(function(require, exports, module) {

    var $ = require('jquery');
    console.log($)

});